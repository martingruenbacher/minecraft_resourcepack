# Villager idle (ambient) sound override pack

This is a **Minecraft Java Edition resource pack** meant for server use, replacing the **villager idle / ambient** sounds with your custom `.ogg` files.

## What you’ll do

1. Find the **exact vanilla filenames** for villager ambient sounds for *your* server version.
2. Put your custom `.ogg` files into `assets/minecraft/sounds/entity/villager/` using those exact names.
3. Zip the pack and configure it in `server.properties`.

## 1) Pick the right `pack_format`

This repo is set up for your Paper server running **1.21.10**.

The pack is currently set to `pack_format: 34` in `pack.mcmeta` (Minecraft **1.21.x**).

If your server is a different version, change `pack_format` accordingly.

## 2) List villager ambient sound filenames (recommended)

Run this in PowerShell from the repo root:

```powershell
./tools/list-villager-ambient-sounds.ps1 -Version 1.21.11
```

It prints lines like (paths vary by version; some versions use `sounds/mob/villager/...`):

```
assets/minecraft/sounds/entity/villager/ambient1.ogg
assets/minecraft/sounds/entity/villager/ambient2.ogg
...
```

Create/rename your custom sounds to match those exact filenames and place them in that folder.

If you want to inspect more than just idle sounds:

```powershell
./tools/list-villager-ambient-sounds.ps1 -Version 1.21.11 -Mode all
```

## 3) Audio requirements (practical defaults)

Minecraft expects **Ogg Vorbis** files (`.ogg`). Common safe settings:

- Mono (or stereo is usually OK, but mono is safest)
- 44.1 kHz sample rate
- Reasonable loudness (avoid clipping)

## 4) Build a zip

```powershell
./tools/build-pack.ps1
```

Output goes to `dist/villager_custom_sounds.zip`.

## 4.1) Get the SHA1 for server.properties

```powershell
./tools/hash-pack.ps1
```

It also writes `dist/villager_custom_sounds.sha1.txt` for easy copy/paste.

## 5) Use it on your server

Host the zip on a web server and set:

- `resource-pack=<https url to villager-idle-pack.zip>`
- `resource-pack-sha1=<sha1 of the zip>`

If you want, I can add a helper script to compute the SHA1 too.
