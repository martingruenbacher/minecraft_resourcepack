package net.gruenbam.villagercustomsounds;

import org.bukkit.Bukkit;
import org.bukkit.SoundCategory;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityAmbientSoundEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.EnumMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import java.util.function.Supplier;

public final class VillagerCustomSoundsPlugin extends JavaPlugin implements Listener {

    private enum Trigger {
        AMBIENT,
        YES,
        NO
    }

    private boolean enabled;
    private SoundCategory soundCategory;
    private float volume;
    private float pitch;
    private Map<Trigger, Map<Villager.Profession, String>> replacements;

    private AutoCloseable protocolLibYesNoInterceptor;

    @Override
    public void onEnable() {
        ensureDefaultConfig();
        reloadPluginConfig();

        Bukkit.getPluginManager().registerEvents(this, this);
        tryEnableProtocolLib();

        getLogger().info("Enabled.");
    }

    @Override
    public void onDisable() {
        if (protocolLibYesNoInterceptor != null) {
            try {
                protocolLibYesNoInterceptor.close();
            } catch (Exception ignored) {
                // best-effort cleanup
            }
            protocolLibYesNoInterceptor = null;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("villagercustomsounds")) {
            return false;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("villagercustomsounds.reload")) {
                sender.sendMessage("You do not have permission.");
                return true;
            }
            reloadConfig();
            reloadPluginConfig();
            sender.sendMessage("VillagerCustomSounds reloaded.");
            return true;
        }

        sender.sendMessage("Usage: /" + label + " reload");
        return true;
    }

    private void reloadPluginConfig() {
        enabled = getConfig().getBoolean("enabled", true);

        String categoryStr = getConfig().getString("sound-category", "NEUTRAL");
        try {
            soundCategory = SoundCategory.valueOf(categoryStr == null ? "NEUTRAL" : categoryStr.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            soundCategory = SoundCategory.NEUTRAL;
            getLogger().warning("Invalid sound-category '" + categoryStr + "', using NEUTRAL");
        }

        volume = (float) getConfig().getDouble("volume", 1.0);
        pitch = (float) getConfig().getDouble("pitch", 1.0);

        replacements = new EnumMap<>(Trigger.class);
        for (Trigger trigger : Trigger.values()) {
            replacements.put(trigger, new EnumMap<>(Villager.Profession.class));
        }

        // New format: replacements.<trigger>.<PROFESSION> = <sound key>
        loadTriggerMappings(Trigger.AMBIENT, "replacements.ambient");
        loadTriggerMappings(Trigger.YES, "replacements.yes");
        loadTriggerMappings(Trigger.NO, "replacements.no");

        // Backward compat: profession-sounds.* (treated as ambient replacements)
        ConfigurationSection legacy = getConfig().getConfigurationSection("profession-sounds");
        if (legacy != null) {
            Map<Villager.Profession, String> ambient = replacements.get(Trigger.AMBIENT);
            int loaded = 0;
            for (String key : legacy.getKeys(false)) {
                String soundKey = legacy.getString(key);
                if (soundKey == null || soundKey.isBlank()) {
                    continue;
                }
                try {
                    Villager.Profession profession = Villager.Profession.valueOf(key.trim().toUpperCase());
                    if (!ambient.containsKey(profession)) {
                        ambient.put(profession, soundKey.trim());
                        loaded++;
                    }
                } catch (IllegalArgumentException ignored) {
                    getLogger().warning("Unknown profession key in config: " + key);
                }
            }
            if (loaded > 0) {
                getLogger().warning("Config key 'profession-sounds' is deprecated; move to 'replacements.ambient'.");
            }
        }

        getLogger().info(
                "Loaded replacements: ambient=" + replacements.get(Trigger.AMBIENT).size() +
                ", yes=" + replacements.get(Trigger.YES).size() +
                ", no=" + replacements.get(Trigger.NO).size()
        );
    }

    private void loadTriggerMappings(Trigger trigger, String path) {
        ConfigurationSection section = getConfig().getConfigurationSection(path);
        if (section == null) {
            return;
        }

        Map<Villager.Profession, String> map = replacements.get(trigger);
        for (String key : section.getKeys(false)) {
            String soundKey = section.getString(key);
            if (soundKey == null || soundKey.isBlank()) {
                continue;
            }
            try {
                Villager.Profession profession = Villager.Profession.valueOf(key.trim().toUpperCase());
                map.put(profession, soundKey.trim());
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("Unknown profession key in config at " + path + ": " + key);
            }
        }
    }

    private void ensureDefaultConfig() {
        // We generate defaults in code so this plugin works even without a bundled config.yml.
        var cfg = getConfig();

        cfg.addDefault("enabled", true);
        cfg.addDefault("sound-category", "NEUTRAL");
        cfg.addDefault("volume", 1.0);
        cfg.addDefault("pitch", 1.0);

        // By default we do NOT override any profession (so vanilla sounds remain unchanged).
        // Configure any of these keys to replace only some professions:
        // - replacements.ambient.<PROFESSION>
        // - replacements.yes.<PROFESSION>
        // - replacements.no.<PROFESSION>
        //
        // Example:
        // cfg.addDefault("replacements.ambient.LIBRARIAN", "villagercustomsounds:villager/librarian_idle");

        cfg.options().copyDefaults(true);
        saveConfig();
    }

    @EventHandler
    public void onAmbient(EntityAmbientSoundEvent event) {
        if (!enabled) {
            return;
        }

        LivingEntity entity = event.getEntity();
        if (!(entity instanceof Villager villager)) {
            return;
        }

        String soundKey = replacements.get(Trigger.AMBIENT).get(villager.getProfession());
        if (soundKey == null || soundKey.isBlank()) {
            return; // keep vanilla
        }

        event.setCancelled(true);
        villager.getWorld().playSound(villager.getLocation(), soundKey, soundCategory, volume, pitch);
    }

    private void tryEnableProtocolLib() {
        if (Bukkit.getPluginManager().getPlugin("ProtocolLib") == null) {
            getLogger().info("ProtocolLib not found. Profession-specific YES/NO replacements are disabled.");
            return;
        }

        try {
            Class<?> interceptorClass = Class.forName("net.gruenbam.villagercustomsounds.ProtocolLibYesNoInterceptor");

            BooleanSupplier enabledSupplier = () -> enabled && (!replacements.get(Trigger.YES).isEmpty() || !replacements.get(Trigger.NO).isEmpty());
            Function<Villager.Profession, String> yesMapper = profession -> replacements.get(Trigger.YES).get(profession);
            Function<Villager.Profession, String> noMapper = profession -> replacements.get(Trigger.NO).get(profession);
            Supplier<SoundCategory> categorySupplier = () -> soundCategory;
            Supplier<Float> volumeSupplier = () -> volume;
            Supplier<Float> pitchSupplier = () -> pitch;

            Constructor<?> ctor = interceptorClass.getDeclaredConstructor(
                    JavaPlugin.class,
                    BooleanSupplier.class,
                    Function.class,
                    Function.class,
                    Supplier.class,
                    Supplier.class,
                    Supplier.class
            );
            ctor.setAccessible(true);
            Object instance = ctor.newInstance(
                    this,
                    enabledSupplier,
                    yesMapper,
                    noMapper,
                    categorySupplier,
                    volumeSupplier,
                    pitchSupplier
            );

            Method open = interceptorClass.getDeclaredMethod("open");
            open.setAccessible(true);
            open.invoke(instance);

            protocolLibYesNoInterceptor = (AutoCloseable) instance;
            getLogger().info("ProtocolLib detected. YES/NO replacements enabled.");
        } catch (Throwable t) {
            getLogger().warning("ProtocolLib detected but interceptor failed to initialize. YES/NO replacements disabled.");
            getLogger().warning("Reason: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }
}
