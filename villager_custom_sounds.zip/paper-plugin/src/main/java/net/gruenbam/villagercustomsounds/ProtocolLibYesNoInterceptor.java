package net.gruenbam.villagercustomsounds;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.BlockPosition;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import java.util.function.Supplier;

final class ProtocolLibYesNoInterceptor implements AutoCloseable {

    private static final String VANILLA_AMBIENT = "minecraft:entity.villager.ambient";
    private static final String VANILLA_YES = "minecraft:entity.villager.yes";
    private static final String VANILLA_NO = "minecraft:entity.villager.no";

    private final JavaPlugin plugin;
    private final ProtocolManager protocolManager;

    private final BooleanSupplier enabled;
    private final Function<Villager.Profession, String> ambientSoundKey;
    private final Function<Villager.Profession, String> yesSoundKey;
    private final Function<Villager.Profession, String> noSoundKey;
    private final Supplier<SoundCategory> soundCategory;
    private final Supplier<Float> volume;
    private final Supplier<Float> pitch;

    private final PacketType entitySoundPacketType;
    private final PacketType namedSoundPacketType;

    private PacketAdapter adapter;

    ProtocolLibYesNoInterceptor(
            JavaPlugin plugin,
            BooleanSupplier enabled,
            Function<Villager.Profession, String> ambientSoundKey,
            Function<Villager.Profession, String> yesSoundKey,
            Function<Villager.Profession, String> noSoundKey,
            Supplier<SoundCategory> soundCategory,
            Supplier<Float> volume,
            Supplier<Float> pitch
    ) {
        this.plugin = Objects.requireNonNull(plugin);
        this.protocolManager = ProtocolLibrary.getProtocolManager();
        this.enabled = Objects.requireNonNull(enabled);
        this.ambientSoundKey = Objects.requireNonNull(ambientSoundKey);
        this.yesSoundKey = Objects.requireNonNull(yesSoundKey);
        this.noSoundKey = Objects.requireNonNull(noSoundKey);
        this.soundCategory = Objects.requireNonNull(soundCategory);
        this.volume = Objects.requireNonNull(volume);
        this.pitch = Objects.requireNonNull(pitch);

        // ProtocolLib packet names vary a bit across versions.
        // Resolve them dynamically so we can compile and run across ProtocolLib 5.x.
        this.entitySoundPacketType = firstAvailablePacketType(
                "ENTITY_SOUND_EFFECT",
                "ENTITY_SOUND",
                "SOUND_ENTITY"
        );
        this.namedSoundPacketType = firstAvailablePacketType(
                "NAMED_SOUND_EFFECT",
                "NAMED_SOUND"
        );
    }

    void open() {
        if (adapter != null) {
            return;
        }

        List<PacketType> types = new ArrayList<>();
        if (entitySoundPacketType != null) {
            types.add(entitySoundPacketType);
        }
        if (namedSoundPacketType != null) {
            types.add(namedSoundPacketType);
        }
        if (types.isEmpty()) {
            plugin.getLogger().warning("ProtocolLib is present, but no supported sound packet types were found. Replacements disabled.");
            return;
        }

        adapter = new PacketAdapter(
                plugin,
                ListenerPriority.NORMAL,
                types.toArray(new PacketType[0])
        ) {
            @Override
            public void onPacketSending(PacketEvent event) {
                if (!enabled.getAsBoolean()) {
                    return;
                }

                PacketContainer packet = event.getPacket();
                String soundKey = readSoundKey(packet);
                if (soundKey == null) {
                    return;
                }

                boolean isAmbient = VANILLA_AMBIENT.equals(soundKey);
                boolean isYes = VANILLA_YES.equals(soundKey);
                boolean isNo = VANILLA_NO.equals(soundKey);
                if (!isAmbient && !isYes && !isNo) {
                    return;
                }

                Villager villager = resolveVillager(event, packet);
                if (villager == null) {
                    return;
                }

                String replacement;
                if (isAmbient) {
                    replacement = ambientSoundKey.apply(villager.getProfession());
                } else if (isYes) {
                    replacement = yesSoundKey.apply(villager.getProfession());
                } else {
                    replacement = noSoundKey.apply(villager.getProfession());
                }
                if (replacement == null || replacement.isBlank()) {
                    return; // keep vanilla
                }

                // Cancel vanilla packet, then play replacement only to this receiver.
                event.setCancelled(true);

                float vol = readVolume(packet, volume.get());
                float pit = readPitch(packet, pitch.get());
                SoundCategory category = soundCategory.get();

                Player player = event.getPlayer();
                Location loc = villager.getLocation();
                Bukkit.getScheduler().runTask(plugin, () -> player.playSound(loc, replacement, category, vol, pit));
            }
        };

        protocolManager.addPacketListener(adapter);
    }

    @Override
    public void close() {
        if (adapter != null) {
            protocolManager.removePacketListener(adapter);
            adapter = null;
        }
    }

    private static String readSoundKey(PacketContainer packet) {
        try {
            Sound sound = packet.getSoundEffects().read(0);
            if (sound == null) {
                return null;
            }
            return sound.getKey().toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    private static float readVolume(PacketContainer packet, float fallback) {
        try {
            return packet.getFloat().read(0);
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static float readPitch(PacketContainer packet, float fallback) {
        try {
            return packet.getFloat().read(1);
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private Villager resolveVillager(PacketEvent event, PacketContainer packet) {
        if (entitySoundPacketType != null && packet.getType() == entitySoundPacketType) {
            try {
                Entity entity = packet.getEntityModifier(event).read(0);
                if (entity instanceof Villager villager) {
                    return villager;
                }
            } catch (Exception ignored) {
                return null;
            }
        }

        if (namedSoundPacketType != null && packet.getType() == namedSoundPacketType) {
            // Not the typical villager yes/no packet, but handle best-effort by locating the nearest villager.
            try {
                BlockPosition pos = packet.getBlockPositionModifier().read(0);
                if (pos == null) {
                    return null;
                }
                Player player = event.getPlayer();
                Location loc = new Location(player.getWorld(), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                Villager closest = null;
                double best = Double.MAX_VALUE;
                for (Entity e : player.getNearbyEntities(16, 16, 16)) {
                    if (!(e instanceof Villager v)) {
                        continue;
                    }
                    double d = v.getLocation().distanceSquared(loc);
                    if (d < best) {
                        best = d;
                        closest = v;
                    }
                }
                return closest;
            } catch (Exception ignored) {
                return null;
            }
        }

        return null;
    }

    private static PacketType firstAvailablePacketType(String... fieldNames) {
        for (String name : fieldNames) {
            try {
                Field f = PacketType.Play.Server.class.getField(name);
                Object v = f.get(null);
                if (v instanceof PacketType pt) {
                    return pt;
                }
            } catch (Throwable ignored) {
                // try next
            }
        }
        return null;
    }
}
