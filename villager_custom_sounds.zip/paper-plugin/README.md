# VillagerCustomSounds (Paper plugin)

Replaces villager sounds for specific professions (and leaves vanilla unchanged for everyone else).

Why a plugin?
- Vanilla villager idle/ambient (`entity.villager.ambient`) does **not** vary by profession.
- A resource pack alone cannot add "if profession == librarian then play X" logic.

## Build

Requirements:
- Java 21
- Maven

From `paper-plugin/`:

```powershell
mvn -q package
```

The jar will be in `paper-plugin/target/`.

## Install

- Drop the jar into your server `plugins/` folder.
- Start the server once to generate `plugins/VillagerCustomSounds/config.yml`.
- Edit config if desired.
- Reload: `/vcs reload`

## Configuring “replace only some”

This plugin replaces villager sounds by intercepting outgoing sound packets via ProtocolLib.

- If a profession is **not** present in the relevant `replacements.*` section, vanilla plays normally.
- If a profession **is** present (non-empty), vanilla is cancelled and your configured sound is played.

### Triggers supported

The plugin supports replacing these villager sounds per profession:

- `ambient` (idle)
- `yes`
- `no`

Config format:

```
replacements:
	ambient:
		CLERIC: villagercustomsounds:villager/cleric_idle
	yes:
		CLERIC: villagercustomsounds:villager/cleric_yes
	no:
		CLERIC: villagercustomsounds:villager/cleric_no
```

Unconfigured professions keep vanilla sounds.

You can point any `replacements.<trigger>.<PROFESSION>` to either:
- a vanilla sound key (e.g. `entity.villager.work_librarian`), or
- a custom namespaced sound key from your resource pack (e.g. `villagercustomsounds:villager/cleric_idle`).

#### ProtocolLib requirement

Minecraft does not expose a cancellable “villager ambient/yes/no with profession context” event on Paper 1.21.x.
So replacements are implemented by intercepting outgoing sound packets via ProtocolLib.

- If ProtocolLib is **not** installed, all `replacements.*` mappings are ignored.
- Install ProtocolLib on the server to enable replacements.

### Using Option A from this repo

This repo provides a namespace `villagercustomsounds`. If you place:

- `assets/villagercustomsounds/sounds/villager/librarian_idle.ogg`

and generate `assets/villagercustomsounds/sounds.json`, then set:

- `profession-sounds.LIBRARIAN: villagercustomsounds:villager/librarian_idle`

Example for your request (multiple variants supported):

- Put files like:
	- `assets/villagercustomsounds/sounds/villager/cleric_idle_1.ogg`
	- `assets/villagercustomsounds/sounds/villager/cleric_idle_2.ogg`
	- `assets/villagercustomsounds/sounds/villager/armorer_idle_1.ogg`
	- `assets/villagercustomsounds/sounds/villager/armorer_idle_2.ogg`

- Generate `sounds.json` and then set in `plugins/VillagerCustomSounds/config.yml`:
	- `profession-sounds.CLERIC: villagercustomsounds:villager/cleric_idle`
	- `profession-sounds.ARMORER: villagercustomsounds:villager/armorer_idle`

For YES/NO, use the same variant scheme:

- Put files like:
	- `assets/villagercustomsounds/sounds/villager/cleric_yes_1.ogg`
	- `assets/villagercustomsounds/sounds/villager/cleric_yes_2.ogg`
	- `assets/villagercustomsounds/sounds/villager/cleric_no_1.ogg`

- Configure:
	- `replacements.yes.CLERIC: villagercustomsounds:villager/cleric_yes`
	- `replacements.no.CLERIC: villagercustomsounds:villager/cleric_no`

## Making the sounds custom

If you use vanilla sound keys (like `entity.villager.work_librarian`) but want them to be *custom*, override the underlying sound files in your resource pack.

For Minecraft 1.21.10, these events map to files under:
- `assets/minecraft/sounds/mob/villager/` (e.g. `librarian1.ogg`, `librarian2.ogg`, ...)

Tip:
- If you want a “clean slate”, you can replace `idle1/2/3.ogg` with silence in the resource pack.
